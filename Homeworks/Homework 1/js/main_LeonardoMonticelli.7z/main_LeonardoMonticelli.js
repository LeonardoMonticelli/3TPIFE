var name = prompt("Greetings user, please enter your name.");
var surName = prompt("Please enter your surname.");
var age = prompt("Now, please enter your age.");

alert("Welcome " + name + " " + surName + "! I see that next year you will be " + (Number(age) + 1) + " years old. ");